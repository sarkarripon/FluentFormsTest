<?php

namespace Tests\Acceptance;

use Tests\Support\AcceptanceTester;

class IntegrationsCest
{
    public function _before(AcceptanceTester $I)
    {
    }

    // tests
    public function tryToTest(AcceptanceTester $I)
    {

    }
}
