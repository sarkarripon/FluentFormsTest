<?php

namespace Tests\Support\Helper\Acceptance\Selectors;

class RenameFormSelec
{
    //rename form
    const rename = "div[id='js-ff-nav-title'] span";
    const renameField = "input[placeholder='Awesome Form']";
    const renameBtn = "div[aria-label='Rename Form'] div[class='el-dialog__footer']";
}