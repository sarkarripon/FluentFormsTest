<?php
namespace Tests\Support\Helper\Acceptance\Selectors;

class PaymentFieldsSelec
{
//    const paymentSection = "(//h5[normalize-space()='Payment Fields'])[1]";
//    const paymentField = "(//div[contains(text(),'Payment Field')])[1]";
//    const subscription = "(//div[contains(text(),'Subscription Field')])[1]";
//    const customPmnt = "(//div[contains(text(),'Custom Payment Amount')])[1]";
//    const itmQty = "(//div[contains(text(),'Item Quantity')])[1]";
//    const pmntMethodField = "(//div[contains(text(),'Payment Method Field')])[1]";
//    const pmntSummary = "(//div[contains(text(),'Payment Summary')])[1]";
//    const coupon = "(//div[contains(text(),'Coupon')])[1]";
}
