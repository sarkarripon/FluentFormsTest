<?php

namespace Tests\Support\Helper\Acceptance\Selectors;

class DeleteFormSelec
{
    //existing form delete buttons
    const deleteBtn = "tbody tr:nth-child(1) td:nth-child(2)";
    const confirmBtn = "/html[1]/body[1]/div[2]/div[1]/button[2]";
}