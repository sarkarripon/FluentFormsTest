<?php
namespace Tests\Support\Helper\Acceptance\Selectors;

class GlobalPageSelec
{
    const pluginPage = '/wp-admin/plugins.php';
    const pluginInstallPage = 'wp-admin/plugin-install.php';
    const newPageCreationPage = '/wp-admin/edit.php?post_type=page';
    const fFormPage = '/wp-admin/admin.php?page=fluent_forms';
    const fFormLicensePage = '/wp-admin/admin.php?page=fluent_forms_add_ons&sub_page=fluentform-pro-add-on';

}
